<?php get_header(); ?>

    <?php 

    if( have_posts() ):

        while( have_posts() ): the_post(); ?>
            <div class="pageBg"></div>
            <div class="m-header">
                <img class="logo" src="http://svgur.com/i/3UE.svg" alt="">
                <div class="burgerMenu">
                    <div class="bm top"></div>
                    <div class="bm middle-b"></div>
                    <div class="bm middle-a"></div>
                    <div class="bm bottom"></div>
                </div>
            </div>
            <nav class="flex animated slideInDown">
                <ul class="header flex">
                    <div class="navigation-rect"></div>
                    <li><a class="navitem " href="">חזרה לדף הבית</a></li>
                    <li><a class="navitem" href="">אודות</a></li>
                    <div class="spacer"></div>
                    <li><a class="navitem navitem-newsletter selected-navitem" href="">הצטרפו אלינו!</a></li>
                    <li class="language-selection">
                        <a class="navitem navitem-arabic" href="">عربي</a>
                        <a class="navitem navitem-english"href="">EN</a>
                    </li>
                </ul>
            </nav>

            <div class="articleMainImg" style="background-image: url('<?php the_field('article_image'); ?>')">
            </div>

            <div class="content">
                <span class="articleDate"><?php the_field('article_date'); ?></span>
                <h1 class="articleTitle"><?php the_field('article_title'); ?> <br>
                    <span class="articleSubTitle"><?php the_field('article_secondary_title'); ?></span>
                </h1>
                <div class="shapeTitle"></div>
                <div class="contentContainer">
                    <div class="wpContent">
                        <?php the_content(); ?>
                    </div>
                    <div class="imagesContainer">
                        <?php if( have_rows('images') ): ?>

                            <?php while( have_rows('images') ): the_row();?>
                                
                                <div class="imgContainer">
                                    <img src="<?php the_sub_field('image'); ?>" alt="">
                                    <span class="imgDescription"><?php the_sub_field('image_description'); ?></span>
                                </div>

                            <?php endwhile; ?>

                        <?php endif; ?>

                        <?php if( have_rows('youtube_videos') ): ?>

                        <?php while( have_rows('youtube_videos') ): the_row();?>

                                <div class="youtubeContainer">
                                    <iframe src="https://www.youtube.com/embed/<?php the_sub_field('youtube_link'); ?>?rel=0" frameborder="0" allowfullscreen></iframe>
                                    <span class="imgDescription"><?php the_sub_field('youtube_link_description'); ?></span>
                                </div>

                            <?php endwhile; ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>








        <?php endwhile;
                
    endif; ?>



     

<?php if( is_front_page() ):
            get_footer();
        else:
            get_footer('blog');
        endif;
?>
