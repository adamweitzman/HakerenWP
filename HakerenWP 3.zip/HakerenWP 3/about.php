<?php
/**
    Template Name:About Page
 */

get_header(); ?>

    <div class="pageBg"></div>
    <div class="m-header">
        <img class="logo" src="http://svgur.com/i/3UE.svg" alt="">
        <div class="burgerMenu">
            <div class="bm top"></div>
            <div class="bm middle-b"></div>
            <div class="bm middle-a"></div>
            <div class="bm bottom"></div>
        </div>
    </div>
    <nav class="flex animated slideInDown">
        <ul class="header flex">
            <div class="navigation-rect"></div>
            <li><a class="navitem " href="../">חזרה לדף הבית</a></li>
            <li><a class="navitem selected-navitem" href="">אודות</a></li>
            <div class="spacer"></div>
            <li><a class="navitem navitem-newsletter " href="">הצטרפו אלינו!</a></li>
            <li class="language-selection">
                <a class="navitem navitem-arabic" href="">عربي</a>
                <a class="navitem navitem-english"href="">EN</a>
            </li>
        </ul>
    </nav>

    <div class="aboutTitleSection flex">
        <div class="aboutTitleContainer">
            <h1 class="aboutTitle">אודות</h1>
            <div class="titleBottomShape"></div>
        </div>
        <div class="allLogos flex">
            <a class="logoLink" href=""><img src='https://i.imgur.com/j8g6dwt.png' /></a>
            <a class="logoLink" href=""><img src='https://i.imgur.com/j8g6dwt.png' /></a>
            <a class="logoLink" href=""><img src='https://i.imgur.com/j8g6dwt.png' /></a>
            <a class="logoLink" href=""><img src='https://i.imgur.com/j8g6dwt.png' /></a>
            <a class="logoLink" href=""><img src='https://i.imgur.com/wQmQgHT.png' /></a>
            <a class="logoLink" href=""><img src='https://i.imgur.com/xMD8qub.png' /></a>
            <a class="logoLink" href=""><img class="fareLogo" src='https://i.imgur.com/a7Grs4m.png' /></a>
        </div>
    </div>
    <div class="content">

        <?php
        if( have_posts() ):

        while( have_posts() ): the_post(); ?>

            <div class="contentContainer">

                <div class="wpContent">

                    <?php the_content(); ?>

                </div>

                <div class="imagesContainer">
                    <?php if( have_rows('images') ): ?>

                        <?php while( have_rows('images') ): the_row();?>

                            <div class="imgContainer">
                                <img src="<?php the_sub_field('image'); ?>" alt="">
                                <span class="imgDescription"><?php the_sub_field('image_description'); ?></span>
                            </div>

                        <?php endwhile; ?>

                    <?php endif; ?>

                    <?php if( have_rows('youtube_videos') ): ?>

                        <?php while( have_rows('youtube_videos') ): the_row();?>

                            <div class="youtubeContainer">
                                <iframe src="https://www.youtube.com/embed/<?php the_sub_field('youtube_link'); ?>?rel=0" frameborder="0" allowfullscreen></iframe>
                                <span class="imgDescription"><?php the_sub_field('youtube_link_description'); ?></span>
                            </div>

                        <?php endwhile; ?>

                    <?php endif; ?>
                </div>

            </div>




        <?php endwhile;

        endif; ?>
    </div>

<?php get_footer(); ?>