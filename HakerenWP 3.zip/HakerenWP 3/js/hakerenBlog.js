let $header = $('nav'),
    $navItem = $('.navitem'),
    $navRect = $('.navigation-rect');

const cl = console.log;

cl('loadedHakeren');

$header.hover(function(){
    $navItem.hover(function(){
        updateRectOffset(this);
    });
}, function(){
    let $selectedNavItem = $('.selected-navitem');
    updateRectOffset($selectedNavItem[0]);
});

function updateRectOffset ($el) {

    let offSetLeft = $el.offsetLeft,
        offSetWidth = $el.offsetWidth,
        newOffSet = offSetLeft + offSetWidth - 20;

    $navRect.css('left', newOffSet + 'px').addClass('nav-rect-width');
    cl($navRect);

}

function selectNavItem($newEl){
    $navItem.map(function(i, e){
        $(e).removeClass('selected-navitem');
    });
    $($newEl).addClass('selected-navitem');
    updateRectOffset($newEl[0]);
}

function findNavItem(){
    let windowScrollTopValue = $window.scrollTop(),
        $oldSelectedNavItem = $('.selected-navitem');
    $sectionsArray.map(function(el){
        let $element = $($sectionsArray[el]),
            sectionOffsetTopValue = $element[0].offsetTop,
            sectionHeight = $element.height();
        if (windowScrollTopValue >= 0 && windowScrollTopValue <= 400) {
            let idValue = $sectionsArray[el].id;
            let $home = $('a[href="#home"]');
            selectNavItem($home);
        }
        if (sectionOffsetTopValue > windowScrollTopValue - 30 && sectionOffsetTopValue < windowScrollTopValue + sectionHeight / 2) {
            let idValue = $sectionsArray[el].id;
            let newNavItem = $('a[href="#' + idValue + '"]');
            selectNavItem(newNavItem);
        }
    });
}

$navItem.click(function(){
    selectNavItem($(this));
});