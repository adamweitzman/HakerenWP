    	
	<script
            src="https://code.jquery.com/jquery-3.2.1.js"
            integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
            crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-visible/1.2.0/jquery.visible.min.js"></script>
    
    <script>
        let windowHeight = $(window).height(),
        titleHeight = $('.title').height(),
        newHomeHeight = windowHeight - titleHeight - 40,
        $homeDiv = $('#home');

        function isiPhone(){
            return (
                (navigator.platform.indexOf("iPhone") != -1)
            );
        }

        console.log('in footer');

        if(isiPhone()){
            console.log('isIphone');
            let iPhoneHomeHeight = windowHeight - 338.75 - 40;
            $homeDiv.css({height:iPhoneHomeHeight + 'px'});
        } else {
            $homeDiv.css({height:newHomeHeight + 'px'});
        }

    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-scrollTo/2.1.2/jquery.scrollTo.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-localScroll/1.4.0/jquery.localScroll.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjs/3.13.3/math.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script async src="https://www.youtube.com/iframe_api"></script>
    <script>
        if ($(window).width() > 480) {
            $('.header, .joinButton').localScroll();
        }
        $(window).scrollTop(0);

    </script>

	<?php wp_footer(); ?>
	</body>
</html>