<?php

function adampress_script_enqueue() {

		// this function loads js and css
//			wp_enqueue_style('fontstyle', get_template_directory_uri() . '/css/stylesheet.css', array(), '1.0.0', 'all');

		if( is_front_page() ):
			wp_enqueue_style('customhakerentyle', get_template_directory_uri() . '/css/customStyle.css', array(), '1.0.0', 'all');
			wp_enqueue_script('myjs', get_template_directory_uri() . '/js/main.js', array(), '1.0.0', true);
		else:
			wp_enqueue_style('customhakerenblogstyle', get_template_directory_uri() . '/css/hakerenBlogStyle.css', array(), '1.0.0', 'all');
			wp_enqueue_script('customjs', get_template_directory_uri() . '/js/hakerenBlog.js', array(), '1.0.0', true);
		endif;

			
		

}

add_action( 'wp_enqueue_scripts', 'adampress_script_enqueue'); // callback to activate function above


// function adampress_theme_setup() {

// 	// this function enables & defines the menu bar

// 	add_theme_support('menus');

// 	register_nav_menu('primary', 'Primary Header Navigation');
// 	register_nav_menu('secondary', 'Footer Navigation');
// }


// add_action('init', 'adampress_theme_setup'); // callback to activate function above

// add_theme_support('custom-background');
// add_theme_support('post-thumbnails');


