<!doctype html>
<html>
	<head>
    <meta charset="UTF-8">
        <link rel="icon" href="https://i.imgur.com/jZxJePr.png">
        <meta name="HandheldFriendly" content="true">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, shrink-to-fit=no" />

    <title>נבחרת לאחריות חברתית</title>
    <link rel="stylesheet"
              href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
		<?php wp_head(); ?>
	</head>

	<body>

