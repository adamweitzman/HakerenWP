<?php 

/*
	Template Name: Landing Page
*/

get_header(); ?>

    <div class="desktop "  >
        <div class="m-header">
            <img class="logo" src="http://svgur.com/i/3UE.svg" alt="">
            <div class="burgerMenu">
                <div class="bm top"></div>
                <div class="bm middle-b"></div>
                <div class="bm middle-a"></div>
                <div class="bm bottom"></div>
            </div>
        </div>
        <nav class="flex animated slideInDown">
            <ul class="header flex">
                <div class="navigation-rect"></div>
                <li><a class="navitem selected-navitem" href="#home">בית</a></li>
                <li><a class="navitem" href="#team">הנבחרת</a></li>
                <li><a class="navitem" href="#articles">עולים למגרש</a></li>
                <li><a class="navitem" href="about">אודות</a></li>
                <div class="spacer"></div>
                <li><a class="navitem navitem-newsletter" href="#contact">הצטרפו אלינו!</a></li>
                <li class="language-selection">
                    <a class="navitem navitem-arabic" href="">عربي</a>
                    <a class="navitem navitem-english"href=""></a>
                </li>
            </ul>
        </nav>
        <div class="pageBg rellax" data-rellax-speed="-3" id="bg1"></div>
        <div class="banner section" id="home">
            <div class="m-bgImg rellax" data-rellax-speed="5">
                <img class="m-mainImg" src="https://images.unsplash.com/photo-1505305976870-c0be1cd39939?dpr=1&auto=format&fit=crop&w=2850&h=&q=60&cs=tinysrgb&crop=" alt="">
                <div class="m-ImgOverlay"></div>
                <div class="m-bottomShape"></div>
            </div>
            <div class="titleCard rellax" data-rellax-speed="3">
                <img src="http://svgur.com/i/3WA.svg" alt="" class="cornerSVG">

                <h1>נבחרת <br>אחריות<br>חברתית</h1>
                <div class="textArea">
                    <img class="twoArrows" src="http://svgur.com/i/3Ux.svg" alt="">
                    <p>טובי השחקנים והשחקניות של הכדורגל הישראלי עולים ביחד למגרש כדי לנצח את הגזענות והאלימות. הנבחרת לאחריות חברתית היא מיזם חדשני שמציב כדורגלנים מובילים מכל קצוות החברה הישראלית בחזית המאבק לשיוויון, סובלנות וקיום משותף</p>
                    <a class="joinButton" href="">הצטרפו אלינו!</a>
                    <div class="allLogos flex">
                        <a class="logoLink" href=""><img src='https://i.imgur.com/j8g6dwt.png' /></a>
                        <a class="logoLink" href=""><img src='http://box5159.temp.domains/~thetean2/wp-content/uploads/2017/10/kicking.png' /></a>
                        <a class="logoLink" href=""><img src='https://i.imgur.com/xMD8qub.png' /></a>

                    </div>
                </div>
            </div>

            <div class="bannerSlider rellax" data-rellax-speed="-3">
                <img class="mainLogo" src="http://svgur.com/i/3UE.svg" alt="">
                <div class="imgContainer">
                    <div class="rellax scene" data-rellax-speed="2">
                        <img data-depth="0.2" src="https://images.unsplash.com/photo-1505305976870-c0be1cd39939?dpr=1&auto=format&fit=crop&w=2850&h=&q=60&cs=tinysrgb&crop=" alt="">
                    </div>
                    <div class="overlay"></div>
                    <div class="bottomShape"></div>
                </div>
                <article>
                    <h3>סיכום הסיבוב הראשון בליגת העל <br>
                        <span>גזענות ואלימות במגרש</span></h3>
                    <a href="" >קראו עוד</a>
                </article>
            </div>
            <img class="arrowSVG" src="http://svgur.com/i/3Ux.svg" alt="">
        </div>
        <div class="theTeam section" id="team">
            <h3 class="sectionTitle">הנבחרת</h3>
            <div class="sectionTitleShape"></div>
            <div class="playerContainer">
                <div class="playerBackground">
                    <video class="playerVideo" autoplay muted loop src="http://box5159.temp.domains/~thetean2/wp-content/uploads/2017/10/Dionyses-Head.mp4">

                    </video>
                    <div class="videoOverlay"></div>
                </div>

                <div class="playerText" >
                    <img class="twoArrows" src="http://svgur.com/i/3Ux.svg" alt="">
                    <span class="playerNumber rellax" data-rellax-speed="-2"></span>
                    <h4 class="playerPosition"></h4>
                    <h4 class="playerTeam"></h4>
                    <div class="playerNameMask">
                        <h1 class="playerName animated slideInUp">הכר את</h1>
                    </div>
                    <div class="playerFamilyNameMask">
                        <h1 class="playerFamilyName animated slideInUp">הנבחרת</h1>
                    </div>
                    <div class="playerShape"></div>
                    <div class="playerParagraphs">
                        <p class="playerStory" style="vertical-align: top;"></p>
                        <p class="playerQuote"></p>
                    </div>
                </div>

                <div id="hiddenTeamInfo" >
                    <ul class="hiddenPlayerInfo" data-player-id="10">
                        <li class="h-playerNumber">10</li>
                        <li class="h-position">חלוץ</li>
                        <li class="h-team">הפועל באר-שבע</li>
                        <li class="h-firstName">אליניב</li>
                        <li class="h-familyName">ברדה</li>
                        <li class="h-text">אחרי קריירה ארוכה ומוצלחת בבלגיה, ברדה חזר אל עיר הולדתו באר שבע, והוביל את הקבוצה שנלחמה על דמותה ועל הישרדותה בליגה לזכיה באליפות היסטורית.</li>
                        <li class="h-quote">"אחד המפתחות להצלחה של באר שבע בשנים האחרונות הוא הקשר האוהדים, שחשוב לי מאוד כשחקן בקבוצה וכבאר שבעי. העשייה המשותפת שלנו למיגור האלימות, והתמקדות באהבה לקבוצה ובעשיה חיובית הם חלק מסוד ההצלחה של המועדון."</li>
                        <li class="h-youtubeLink">http://box5159.temp.domains/~thetean2/wp-content/uploads/2017/10/Dionyses-Head.mp4</li>
                    </ul>
                    <ul class="hiddenPlayerInfo" data-player-id="101">
                        <li class="h-playerNumber">10</li>
                        <li class="h-position">קשרית</li>
                        <li class="h-team">הפועל פתח-תקווה</li>
                        <li class="h-firstName">נורה</li>
                        <li class="h-familyName">אבו-שנב</li>
                        <li class="h-text">לאחר שכבשה יותר מ-90 שערים במדי סכנין, עברה אבו שנב להפועל פתח תקווה ומונתה לקפטנית הקבוצה. במקביל נורה גם מאמנת ילדות, ומחנכת אותן להתמדה ונחישות אל מול הקשיים.</li>
                        <li class="h-quote"> "כילדה הייתי הבת היחידה בכפר ששיחקה כדורגל עם הבנים. היו אנשים שפתחו עיניים אבל אני רציתי את זה מאוד והצבתי עובדה: אני אשחק כדורגל ולא אכפת לי מה יגידו."</li>
                        <li class="h-youtubeLink">http://box5159.temp.domains/~thetean2/wp-content/uploads/2017/10/Dionyses-Head.mp4</li>
                    </ul>
                    <ul class="hiddenPlayerInfo" data-player-id="45">
                        <li class="h-playerNumber">45</li>
                        <li class="h-position">שוער</li>
                        <li class="h-team">הפועל נצרת עלית</li>
                        <li class="h-firstName">אבי</li>
                        <li class="h-familyName">אבגי</li>
                        <li class="h-text">אבגי התפרסם כששימש שוער שני בעונת האליפות של בית"ר י-ם (2007). בשנים האחרונות הוא מוביל מאבק שחקנים משותף נגד קיום משחקים בשבת</li>
                        <li class="h-quote"> "אני כדורגלן, ואני גם אדם עם אמונה חזקה בתורה ובקב"ה, וזה דבר שצריך לכבד. אני חושב שהכדורגל יכול לחזק את הכבוד ההדדי  בין אנשים מרקעים שונים, ורואים את זה אצלנו בקבוצה: ערבים ויהודים, חילוניים ודתיים, ישראלים ושחקנים זרים"</li>
                        <li class="h-youtubeLink">http://box5159.temp.domains/~thetean2/wp-content/uploads/2017/10/Dionyses-Head.mp4</li>
                    </ul>
                </div>

                <div class="m-pitch">
                    <h2 class="displayedShirtNumber">11</h2>
                    <img class="arrowRight" src="http://svgur.com/i/3XB.svg" alt="">
                    <img class="plainShirt" src="http://svgur.com/i/3XL.svg" alt="">
                    <img class="arrowLeft" src="http://svgur.com/i/3XB.svg" alt="">
<!--                    <div class="greenBox"></div>-->
                </div>
            </div>



            <div class="pitch rellax" data-rellax-speed="2">

                <div class="progressComponent">

                    <div class="progressInfoContainer flex">
                        <h6 class="progressText">מיסרו את הכדור בין השחקנים</h6>
<!--                        <span class="info"></span>-->
                        <div class="animated progressNum">
                            <span class="total">14</span>
                            <span> / </span>
                            <span class="num">0</span>
                        </div>
                    </div>

                    <div class="progressBarContainer animation-target">
                        <div class="progressBar" style="width:0%;"></div>
                    </div>
                </div>

                <svg class="pitchSVG" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 420.76 586.85"><defs><style>.cls-1{opacity:0.7;}.cls-2{fill:#fff;}.cls-3{opacity:0.05;}.cls-4{fill:url(#New_Gradient_Swatch_copy);}.cls-5{fill:url(#New_Gradient_Swatch_copy-2);}.cls-6{fill:url(#New_Gradient_Swatch_copy-3);}.cls-7{fill:url(#New_Gradient_Swatch_copy-4);}.cls-8{fill:url(#New_Gradient_Swatch_copy-5);}</style><linearGradient id="New_Gradient_Swatch_copy" x1="1.28" y1="29.34" x2="419.48" y2="29.34" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="#04382e"/><stop offset="0.39" stop-color="#042d33"/><stop offset="1" stop-color="#03213a"/></linearGradient><linearGradient id="New_Gradient_Swatch_copy-2" x1="1.28" y1="146.71" x2="419.48" y2="146.71" xlink:href="#New_Gradient_Swatch_copy"/><linearGradient id="New_Gradient_Swatch_copy-3" x1="1.28" y1="264.08" x2="419.48" y2="264.08" xlink:href="#New_Gradient_Swatch_copy"/><linearGradient id="New_Gradient_Swatch_copy-4" x1="1.28" y1="381.45" x2="419.48" y2="381.45" xlink:href="#New_Gradient_Swatch_copy"/><linearGradient id="New_Gradient_Swatch_copy-5" x1="1.28" y1="498.82" x2="419.48" y2="498.82" xlink:href="#New_Gradient_Swatch_copy"/></defs><title>pitchNew</title><g id="Layer_2" data-name="Layer 2"><g id="Layer_2-2" data-name="Layer 2"><g class="cls-1"><path class="cls-2" d="M326.54,0H0V586.85H420.76V0Zm91.67,22.09A20.89,20.89,0,0,1,398.87,2.56h19.33Zm-157-19.53V34H159.54V2.56ZM157,2.56v34h106.8v-34H324V95.73H96.78V2.56Zm93.73,95.73a51.88,51.88,0,0,1-80.67,0Zm-83.92,0a54.46,54.46,0,0,0,87.16,0h72.58V2.56h69.77a23.45,23.45,0,0,0,21.9,22.09V294.28H264.44a54.07,54.07,0,0,0-108.13,0H2.56V24.65A23.45,23.45,0,0,0,24.45,2.56H94.22V98.29Zm40.89,198.54a3.18,3.18,0,0,0,5.38,0h48.8a51.51,51.51,0,0,1-103,0Zm5.75-2.56a3.17,3.17,0,0,0-6.12,0H158.87a51.52,51.52,0,0,1,103,0ZM21.89,2.56A20.89,20.89,0,0,1,2.56,22.09V2.56ZM2.56,564.34a20.89,20.89,0,0,1,19.36,20H2.56Zm157,20V552.81H261.22v31.48Zm104.24,0v-34H157v34H96.78V491.12H324v93.18ZM170,488.56a51.88,51.88,0,0,1,80.67,0Zm83.92,0a54.46,54.46,0,0,0-87.17,0H94.22v95.73H24.47A23.45,23.45,0,0,0,2.56,561.78V296.83H156.34a54.07,54.07,0,0,0,108.08,0H418.21V561.78a23.45,23.45,0,0,0-21.91,22.52H326.54V488.56Zm144.89,95.73a20.89,20.89,0,0,1,19.36-20v20Z"/><circle class="cls-2" cx="210.38" cy="521.22" r="3.19"/><circle class="cls-2" cx="210.38" cy="65.63" r="3.19"/></g><g class="cls-3"><rect class="cls-4" x="1.28" width="418.21" height="58.69"/><rect class="cls-5" x="1.28" y="117.37" width="418.21" height="58.69"/><rect class="cls-6" x="1.28" y="234.74" width="418.21" height="58.69"/><rect class="cls-7" x="1.28" y="352.11" width="418.21" height="58.69"/><rect class="cls-8" x="1.28" y="469.48" width="418.21" height="58.69"/></g></g></g></svg>
                <div class="players container">
                    <img id="ball" src="http://svgur.com/i/3Vw.svg" alt="">

                    <div class="grid playerRow">
                        <div id="10" class="hasPlayer grid__col grid__col--12-of-12">
                            <img class="player" src="http://svgur.com/i/3WJ.svg" alt="" >

                        </div>
                    </div>
                    <div class="grid playerRow">
                        <div class="hasPlayer grid__col grid__col--3-of-12"  >
                            <img id="11" class="player"  src="http://svgur.com/i/3WK.svg" alt="">

                        </div>
                        <div class="grid__col grid__col--6-of-12"></div>
                        <div  class="hasPlayer grid__col grid__col--3-of-12"  >
                            <img id="8" class="player" src="http://svgur.com/i/3VX.svg" alt="">
                        </div>
                    </div>
                    <div class="grid playerRow">
                        <div class="hasPlayer grid__col grid__col--6-of-12"  >
                            <img id="18" class="player"  src="http://svgur.com/i/3VY.svg" alt="">

                        </div>
                        <div  class="hasPlayer grid__col grid__col--6-of-12"  >
                            <img id="7" class="player" src="http://svgur.com/i/3V3.svg" alt="">
                        </div>
                    </div>
                    <div class="grid playerRow">
                        <div class="hasPlayer grid__col grid__col--3-of-12"  >
                            <img id="101" class="player"  src="http://svgur.com/i/3WJ.svg" alt="" >
                        </div>
                        <div class="hasPlayer grid__col grid__col--6-of-12"  >
                            <img id="13" class="player"  src="http://svgur.com/i/3Uy.svg" alt="">

                        </div>
                        <div class="hasPlayer grid__col grid__col--3-of-12">
                            <img id="20" class="player"  src="http://svgur.com/i/3Ui.svg" alt="">
                        </div>
                    </div>
                    <div class="grid playerRow">
                        <div  class="hasPlayer grid__col grid__col--6-of-12"  >
                            <img id="6" class="player" src="http://svgur.com/i/3Vc.svg" alt="">
                        </div>
                        <div  class="hasPlayer grid__col grid__col--6-of-12"  >
                            <img id="9" class="player" src="http://svgur.com/i/3Vd.svg" alt="">
                        </div>
                    </div>
                    <div class="grid playerRow">
                        <div class="hasPlayer grid__col grid__col--3-of-12"  >
                            <img id="15" class="player"  src="http://svgur.com/i/3V4.svg" alt="">
                        </div>
                        <div class="hasPlayer grid__col grid__col--6-of-12"  >
                            <img id="21" class="player"  src="http://svgur.com/i/3Tt.svg" alt="">
                        </div>
                        <div  class="hasPlayer grid__col grid__col--3-of-12"  >
                            <img id="3" class="player" src="http://svgur.com/i/3Vy.svg" alt="">
                        </div>
                    </div>
                    <div class="grid playerRow">
                        <div  class="hasPlayer grid__col grid__col--12-of-12"  >
                            <img id="45" class="player"  src="http://svgur.com/i/3WB.svg" alt="">
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div class="articles section" id="articles">
            <h3 class="sectionTitle">עולים למגרש</h3>
            <div class="sectionTitleShape"></div>
            <div class="articlesWrapper">
                <div class="article mainArticle " data-parent-id="1">
                    <a href="">
                        <div class="articleImgContainer" data-class='scene' style="background-image: url(https://images.unsplash.com/photo-1487466365202-1afdb86c764e?dpr=1&auto=format&fit=crop&w=1952&q=60&cs=tinysrgb)">
<!--                            <img class="articleImg" data-depth="0.1" src="https://images.unsplash.com/photo-1487466365202-1afdb86c764e?dpr=1&auto=format&fit=crop&w=1952&q=60&cs=tinysrgb" alt="">-->
                            <div class="overlayBg"></div>
                        </div>
                        <div class="articleText">
                            <h5 class="articleDate">11/10/17</h5>
                            <h2 class="articleTitle"> סיכום הסיבוב הראשון בליגת העל<span><br> גזענות ואלימות במגרש</span></h2>
                            <!--div.tags will go here-->
                        </div>
                        <div class="readMoreBtn flex">
                            <img class="animated" src="http://svgur.com/i/3WV.svg" alt="">
                            <h3 class="animated">קרא עוד</h3>
                        </div>
                    </a>
                </div>

            </div>
            <div class="articlesWrapper flex flex-wrapper">
                <div class="article">
                    <a href="">
                        <div class="articleImgContainer" style="background-image: url(https://images.unsplash.com/photo-1487466365202-1afdb86c764e?dpr=1&auto=format&fit=crop&w=1952&q=60&cs=tinysrgb)" >
<!--                            <img class="articleImg" data-depth="0.1" src="https://images.unsplash.com/photo-1487466365202-1afdb86c764e?dpr=1&auto=format&fit=crop&w=1952&q=60&cs=tinysrgb" alt="">-->
                            <div class="overlayBg"></div>
                        </div>
                        <div class="articleText">
                            <h5 class="articleDate">11/10/17</h5>
                            <h2 class="articleTitle"> סיכום הסיבוב הראשון בליגת העל<span><br> גזענות ואלימות במגרש</span></h2>
                            <!--div.tags will go here-->
                        </div>
                        <div class="readMoreBtn flex">
                            <img class="animated" src="http://svgur.com/i/3WV.svg" alt="">
                            <h3 class="animated">קרא עוד</h3>
                        </div>
                    </a>
                </div>
                <div class="article">
                    <a href="">
                        <div class="articleImgContainer" style="background-image: url(https://images.unsplash.com/photo-1487466365202-1afdb86c764e?dpr=1&auto=format&fit=crop&w=1952&q=60&cs=tinysrgb)">
<!--                            <img class="articleImg" data-depth="0.1" src="https://images.unsplash.com/photo-1487466365202-1afdb86c764e?dpr=1&auto=format&fit=crop&w=1952&q=60&cs=tinysrgb" alt="">-->
                            <div class="overlayBg"></div>
                        </div>
                        <div class="articleText">
                            <h5 class="articleDate">11/10/17</h5>
                            <h2 class="articleTitle"> סיכום הסיבוב הראשון בליגת העל<span><br> גזענות ואלימות במגרש</span></h2>
                            <!--div.tags will go here-->
                        </div>
                        <div class="readMoreBtn flex">
                            <img class="animated" src="http://svgur.com/i/3WV.svg" alt="">
                            <h3 class="animated">קרא עוד</h3>
                        </div>
                    </a>
                </div>
            </div>
        </div>

    </div>

    </div>
    <footer class="contact" id="contact">
        <img class="logo" src="http://svgur.com/i/3UE.svg" alt="">
        <h3 class="sectionTitle" style="color:#03213A;">הצטרפו אלינו</h3>
        <div class="sectionTitleShape"></div>
        <h4 class="sectionSubtitle">רוצים להישאר מעודכנים וללמוד עוד על הנבחרת? השאירו כאן פרטים:</h4>

        <form id="hakerenForm" action="">
                <input  class="formInput" placeholder="שם מלא" type="text" name="name">
                <input class="formInput" placeholder="מייל" type="email" name="email">

                <input class="formInput" placeholder="טלפון" type="tel" name="number" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>

            <input type="submit" value="שליחה" class="sendBtn sendDeactive">

        </form>
        <h4 class="phonenumber">theteam.org.il | theteamisr@gmail.com | 052-4439276</h4>
        <a href="" class="adam" style="pointer-events: none; text-decoration: none"><img
                    src="http://svgur.com/i/3Yw.svg" alt="">UI/UX Design & Development by </a>
        <h6>Powered by WordPress</h6>

        <div id="bgBottom"></div>
    </footer>

<?php get_footer(); ?>