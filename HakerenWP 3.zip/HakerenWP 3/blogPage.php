<?php

/*
	Template Name: BlogPage
*/

get_header(); ?>



<?php get_footer(); ?>